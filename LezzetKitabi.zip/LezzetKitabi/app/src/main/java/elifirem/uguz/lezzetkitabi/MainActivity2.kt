package elifirem.uguz.lezzetkitabi

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import elifirem.uguz.lezzetkitabi.databinding.ActivityMain2Binding

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnkaydet.setOnClickListener {
            var kullaniciBilgisi = binding.kayitkullaniciadi.text.toString()
            var kullaniciSifre = binding.kayitsifre.text.toString()

            // Kullanıcıya özel SharedPreferences oluştur
            var preferences = this.getSharedPreferences("bilgiler_$kullaniciBilgisi", MODE_PRIVATE)
            var editor = preferences.edit()

            // Veri ekleme
            editor.putString("kullanici", kullaniciBilgisi).apply()
            editor.putString("sifre", kullaniciSifre).apply()

            Toast.makeText(applicationContext, "Kayıt Başarılı", Toast.LENGTH_LONG).show()
            binding.kayitkullaniciadi.text.clear()
            binding.kayitsifre.text.clear()
        }

        binding.btngirisedon.setOnClickListener {
            intent = Intent(applicationContext, MainActivity::class.java)
            startActivity(intent)
        }
    }
}
