package elifirem.uguz.lezzetkitabi

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import elifirem.uguz.lezzetkitabi.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    lateinit var preferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        preferences = getSharedPreferences("bilgiler", MODE_PRIVATE)

        // Kullanıcı girişi kontrolü
        if (isLoggedIn()) {
            startMainActivity3()
        }

        binding.button4.setOnClickListener {
            val girisKullanici = binding.editTextTextPersonName.text.toString()
            val girisSifre = binding.editTextTextPassword2.text.toString()

            if (isValidCredentials(girisKullanici, girisSifre)) {
                saveLoginState() // Kullanıcı girişi başarılıysa durumu kaydet
                startMainActivity3()
            } else {
                Toast.makeText(applicationContext, "Giriş Bilgileri Hatalı..", Toast.LENGTH_LONG).show()
            }
        }

        binding.button5.setOnClickListener {
            intent = Intent(applicationContext, MainActivity2::class.java)
            startActivity(intent)
        }
    }

    private fun isValidCredentials(kullaniciAdi: String, sifre: String): Boolean {
        val kayitliKullanici = preferences.getString("kullanici", "")
        val kayitliSifre = preferences.getString("sifre", "")

        return !kullaniciAdi.isEmpty() && !sifre.isEmpty() && kayitliKullanici == kullaniciAdi && kayitliSifre == sifre
    }

    private fun isLoggedIn(): Boolean {
        // Kullanıcı daha önce giriş yapmış mı kontrol et
        return preferences.getBoolean("isLoggedIn", false)
    }

    private fun saveLoginState() {
        // Kullanıcı girişini kaydet
        preferences.edit().putBoolean("isLoggedIn", true).apply()
    }

    private fun startMainActivity3() {
        // MainActivity3'e git
        intent = Intent(applicationContext, MainActivity3::class.java)
        startActivity(intent)
    }
}
